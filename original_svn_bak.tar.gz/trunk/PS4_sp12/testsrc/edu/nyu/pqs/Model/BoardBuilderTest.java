package edu.nyu.pqs.Model;

import static org.junit.Assert.*;
import org.junit.Test;

import edu.nyu.pqs.Model.Board;
import edu.nyu.pqs.Model.BoardBuilder;

public class BoardBuilderTest {

	/**
	 * Test the board builder to verify whether can generate a new board.
	 */
	@Test
	public void boardBuilderTest() {
		Board board = new BoardBuilder().withCol(7).withRow(6).build();
		assertTrue(board instanceof Board);
	}

}
