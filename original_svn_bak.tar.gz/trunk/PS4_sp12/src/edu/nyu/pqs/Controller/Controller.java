package edu.nyu.pqs.Controller;

import edu.nyu.pqs.Model.Board;
import edu.nyu.pqs.Model.ComputerPlayer;
import edu.nyu.pqs.Model.IPlayer;
import edu.nyu.pqs.View.*;

public class Controller {

	private ConnectFourGUI guiView;
	private IPlayer playerA;
	private IPlayer playerB;
	private Board board;
	private IPlayer currentPlayer;

	public void setCurrentPlayer(IPlayer currentPlayer) {
		this.currentPlayer = currentPlayer;
	}

	public void setGuiView(ConnectFourGUI guiView) {
		this.guiView = guiView;
	}

	public void setPlayerA(IPlayer playerA) {
		this.playerA = playerA;
	}

	public void setPlayerB(IPlayer playerB) {
		this.playerB = playerB;
	}

	public void setBoard(Board board) {
		this.board = board;
	}

	/**
	 * Constructor. Set currentPlayer.
	 */
	public Controller() {
		currentPlayer = playerB;
	}

	/**
	 * Execute one step moving by human.
	 * @param col The column get from ActionListener
	 */
	public void humanPlay(int col) {
		currentPlayer.setMove(col);
		currentPlayer.play();
		guiView.boardRepaint();
		switchToNextPlayer();
	}

	/**
	 * Always switch to next Player.
	 */
	public void switchToNextPlayer() {
		if (board.isOver()) {
			guiView.gameOver();
		} else {
			currentPlayer = (currentPlayer == playerA) ? playerB : playerA;
			if (currentPlayer instanceof ComputerPlayer) {
				computerPlay();
			}
		}
	}

	/**
	 * Execute one step moving by computer.
	 */
	private void computerPlay() {
		currentPlayer.play();
		guiView.boardRepaint();
		switchToNextPlayer();
	}

}